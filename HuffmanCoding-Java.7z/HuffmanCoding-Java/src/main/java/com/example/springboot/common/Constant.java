package com.example.springboot.common;

public class Constant {
    public static final String SIGN_PARENT = "¤";
    public static final String PATH_SAVE_FILE="C:\\Users\\ghgh\\Desktop\\item\\sujujiegouSpringboot\\source\\json.json";
    public static final String PATH_WORDS_FILE="C:\\Users\\ghgh\\Desktop\\item\\sujujiegouSpringboot\\source\\words.txt";
}