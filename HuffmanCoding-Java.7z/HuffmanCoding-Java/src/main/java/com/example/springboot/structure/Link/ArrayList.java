package com.example.springboot.structure.Link;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class ArrayList<T> implements Cloneable, Serializable,Iterable<T> {
    private static final int DEFAULT_SIZE=16;
    private Object[] data;
    private int nowSize;
    private int MaxSize;
    public ArrayList() {
        data=new Object[DEFAULT_SIZE];
        nowSize=0;
        MaxSize=DEFAULT_SIZE;
    }
    @Override
    public int hashCode() {
        return data.hashCode();
    }
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        /*
        应该实现接口继承查询是否为一个接口的
        if (!(o instanceof List)) {
            return false;
        }*/
        boolean equal = (o.getClass() == ArrayList.class)
                ? equalsArrayList((ArrayList<?>) o)
                : equalsRange((List<?>) o);
        return equal;
    }
    public boolean equalsArrayList(ArrayList<?> o){
        if(o.getNowSize()==nowSize){
            for(int i =0;i<nowSize;i++){
                if(!data[i].equals(o.getElement(i))){
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    @Override
    protected Object clone() throws CloneNotSupportedException {
        ArrayList<?> v = (ArrayList<?>) super.clone();
        v.data=Arrays.copyOf(data,nowSize);
        return v;
    }
    public boolean equalsRange(List<?> o){
        if(o.size()==nowSize){
            for(int i =0;i<nowSize;i++){
                if(!data[i].equals(o.get(i))){
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    public int getNowSize() {
        return nowSize;
    }
    public T getElement(int index){
        if(index<0||index>=nowSize){
            return null;
        }else {
            return (T)data[index];
        }
    }
    public void setNowSize(int nowSize) {
        this.nowSize = nowSize;
    }
    public boolean isEmpty(){
        return nowSize==0;
    }
    public boolean isFull(){
        return nowSize == MaxSize;
    }
    public void appendArray(){
        this.data = Arrays.copyOf(data,MaxSize*2);
        MaxSize*=2;
    }
    public void addFirst(T value){
        if(isFull()){
            appendArray();
        }
        for(int i = nowSize-1;i>=0;i--){
            data[i+1]=data[i];
        }
        data[0]=value;
    }
    public void addLast(T value){
        if(isFull()){
            appendArray();
        }
        data[nowSize++]=value;
    }
    //0开始在index后插入
    public void add(T value,int index){
        if(index<0){
            return;
        }else if(index==0){
            addFirst(value);
        }else if(index>=nowSize){
            addLast(value);
        }else{
            if(isFull()){
                appendArray();
            }
            for(int i = nowSize-1;i>index;i--){
                data[i+1]=data[i];
            }
            data[index+1]=value;
        }
    }
    public void deleteFirst(){
        if(!isEmpty()){
            if (nowSize - 1 >= 0) {
                System.arraycopy(data, 1, data, 0, nowSize - 1);
                nowSize--;
            }
        }
    }
    public void deleteLast(){
        if(!isEmpty()) {
            data[nowSize--] = null;
        }
    }
    public void delete(int index){
        if(!isEmpty()){
            if(index==0){
                deleteFirst();
            }else if(index==nowSize-1){
                deleteLast();
            }else if(index>0&&index<nowSize-1){
                System.arraycopy(data, index + 1, data, index + 1 - 1, nowSize - (index + 1));
                data[nowSize--] = null;
            }

        }
    }
    private class Compare<T> implements Comparator<T>{
        @Override
        public int compare(T o1, T o2) {
            return (o1.hashCode()>o2.hashCode())?0:1;
        }
    }
    private Compare getCompare(){
        return new Compare();
    }
    public void sortArray(){
        Arrays.sort((T[])data,getCompare());
    }
    public int contain(Object t){
        for(int i = 0;i<nowSize;i++){
            if(t.equals(data[i])){
                return i;
            }
        }
        return -1;
    }
    @Override
    public Iterator<T> iterator() {
        return new Itr();
    }
    private class Itr implements Iterator<T> {
        private int cursor;
        @Override
        public boolean hasNext() {
            return cursor != nowSize;
        }
        @Override
        public T next() {
            return getElement(cursor++);
        }
    }
}