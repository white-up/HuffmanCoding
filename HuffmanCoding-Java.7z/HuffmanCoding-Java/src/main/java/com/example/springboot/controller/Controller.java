package com.example.springboot.controller;

import com.alibaba.fastjson.JSON;
import com.example.springboot.FileUtil;
import com.example.springboot.common.Result;
import com.example.springboot.entity.Character;
import com.example.springboot.entity.Code;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;

@RestController
@RequestMapping("/echarts")
public class Controller {
    Code code;
    @GetMapping("/tree")
    public Result<?> tree(){
        if(code ==null){
            return Result.error("404","please input hot character");
        }
        return Result.success(code.character);
    }
    @GetMapping("/test")
    public Result<?> test(){
        if(code ==null){
            return Result.error("404","please input hot character");
        }
        return Result.success(code);
    }
    @GetMapping("/getCode")
    public Result<?> getCode(){
        if(code ==null){
            return Result.error("404","please input hot character");
        }
        return Result.success(code.dictionary);
    }
    @PostMapping("/input")
    public Result<?> input(@RequestBody Character[]characters){
        Code code = new Code(Arrays.asList(characters));
        this.code = code;
        //json存储:覆盖
        FileUtil.writeJson(JSON.toJSONString(code.character),false);
        return Result.success(code);
    }

    @PostMapping("/inputString")
    public Result<?> inputString(@RequestBody String words){
        //get characters
        Code code = new Code(words);
        this.code = code;
        //json存储:覆盖
        FileUtil.writeJson(JSON.toJSONString(code.character),false);
        return Result.success(code);
    }
    @GetMapping("/jsonRead")
    public Result<?> fileRead(){
        String json = FileUtil.readJson();
        if (json==null){
            return Result.error("404","file is null");
        }
        Code code = new Code();
        this.code = code;
        return Result.success(code);
    }
    @GetMapping("/wordsRead")
    public Result<?> wordsRead(){
        Code code = new Code(false);
        if (code.character==null){
            return Result.error("404","file is null");
        }
        this.code = code;
        return Result.success(code);
    }
    @PostMapping("encode")
    public Result<?> encode(@RequestBody String words){
        return Result.success(code.encoding(words));
    }
    @PostMapping("decode")
    public Result<?> decode(@RequestBody String words){
        return Result.success(code.decoding(words));
    }

}