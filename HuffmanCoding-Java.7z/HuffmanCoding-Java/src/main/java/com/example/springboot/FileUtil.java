package com.example.springboot;

import com.example.springboot.common.Constant;

import java.io.*;

public class FileUtil {
    public static String readJson(String jsonPath){
        File jsonFile = new File(jsonPath);
        try {
            FileReader fileReader = new FileReader(jsonFile);
            BufferedReader reader = new BufferedReader(fileReader);
            StringBuilder sb = new StringBuilder();
            while (true) {
                int ch = reader.read();
                if (ch != -1) {
                    sb.append((char) ch);
                } else {
                    break;
                }
            }
            fileReader.close();
            reader.close();
            return sb.toString();
        } catch (IOException e) {
            return null;
        }
    }
    public static String readJson(){
        return readJson(Constant.PATH_SAVE_FILE);
    }
    /**
     * 往json文件中写入数据
     * @param jsonPath json文件路径
     * @param flag 写入状态，true表示在文件中追加数据，false表示覆盖文件数据
     * @return 写入文件状态  成功或失败
     */
    public static boolean writeJson(String jsonPath,String data,boolean flag) {
        File jsonFile = new File(jsonPath);
        try {
            // 文件不存在就创建文件
            if (!jsonFile.exists()) {
                jsonFile.createNewFile();
            }
            FileWriter fileWriter = new FileWriter(jsonFile.getAbsoluteFile(), flag);
            BufferedWriter bw = new BufferedWriter(fileWriter);
            bw.write(data);
            bw.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }
    public static boolean writeJson(String data,boolean flag){
        return writeJson(Constant.PATH_SAVE_FILE,data,flag);
    }

}