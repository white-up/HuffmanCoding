package com.example.springboot.structure;

import com.example.springboot.entity.Character;
import lombok.Data;

import java.util.List;

@Data
public class PriorityQueue {
    private MaxHeap maxHeap;
    public PriorityQueue() {
        maxHeap = new MaxHeap();
    }
    public PriorityQueue(Character[] characters) {
        maxHeap = new MaxHeap(characters);
    }
    public void enQueue(Character character){
        maxHeap.add(character);
    }
    public Character deQueue(){
        return maxHeap.extractMax();
    }
}