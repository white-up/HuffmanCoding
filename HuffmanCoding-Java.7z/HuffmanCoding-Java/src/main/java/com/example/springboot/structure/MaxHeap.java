package com.example.springboot.structure;


import com.example.springboot.entity.Character;
import lombok.Data;

import java.util.ArrayList;
import java.util.Arrays;
@Data
public class MaxHeap {
    ArrayList<Character> data;
    public MaxHeap() {
        data = new ArrayList<>();
    }
    public MaxHeap(Character[] characters){
        data=new ArrayList<>(characters.length);
        data.addAll(Arrays.asList(characters));
        //第一个非叶子结点
        for(int i = parent(data.size()-1);i>=0;i--){
            siftDown(i);
        }
    }
    public void add(Character character){
        data.add(character);
        siftUp(data.size()-1);
    }
    public Character extractMax(){
        if(isEmpty()){
            return null;
        }
        Character max = data.get(0);
        data.set(0,data.get(data.size()-1));
        data.remove(data.size()-1);
        siftDown(0);
        return max;
    }
    //上浮
    private void siftUp(int i) {
        while (i>0&&(data.get(i).getValue()<data.get(parent(i)).getValue())){
            swap(i,parent(i));
            i=parent(i);
        }
    }

    //下浮
    private void siftDown(int i){
        while (leftChild(i)<data.size()){
            int j = leftChild(i);
            if(j+1<data.size()
                    &&(data.get(j+1).getValue()<=data.get(j).getValue())){
                j++;
            }
            if(data.get(i).getValue()<=data.get(j).getValue()){
                break;
            }else {
                swap(i,j);
                i=j;
            }
        }
    }
    public Character peek(){
        if (isEmpty()){
            return null;
        }
        return data.get(0);
    }
    public boolean isEmpty(){
        return data.size()==0;
    }
    private void swap(int i,int j){
        Character temp = data.get(i);
        data.set(i,data.get(j));
        data.set(j,temp);
    }
    private int parent(int i){
        return (i-1)>>1;
    }
    private int leftChild(int i){
        return (i<<1)+1;
    }
}