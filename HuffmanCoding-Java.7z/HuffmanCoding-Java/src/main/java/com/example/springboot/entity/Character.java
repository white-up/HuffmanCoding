package com.example.springboot.entity;

import com.example.springboot.common.Constant;
import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

@Data
public class Character implements Serializable {
    String name;
    Integer value;
    ArrayList<Character>children;

    public Character(String character, Integer hot) {
        this.name = character;
        this.value = hot;
        children = new ArrayList<>(2);
    }

    public static void getLeave(HashMap<String, String> ans, Character character, String code){
        //no leave节点
        if(character.getName().equals(Constant.SIGN_PARENT)){
            getLeave(ans,character.getChildren().get(0),code+"0");
            //right
            getLeave(ans,character.getChildren().get(1),code+"1");
        }else {
            ans.put(character.getName(),code);
        }
    }
}