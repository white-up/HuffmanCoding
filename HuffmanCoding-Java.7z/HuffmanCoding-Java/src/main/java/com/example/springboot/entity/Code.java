package com.example.springboot.entity;

import com.alibaba.fastjson.JSON;
import com.example.springboot.FileUtil;
import com.example.springboot.common.Constant;
import com.example.springboot.structure.PriorityQueue;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class Code implements Serializable {
    public Character character;
    public HashMap<String,String> dictionary;
    //characters数组添加
    public Code(List<Character> characters) {
        creatDictionary(characters);
    }
    //读取json(words)预制
    public Code() {
        String json = FileUtil.readJson();
        Character characters = JSON.parseObject(json,Character.class);
        creatDictionary(characters);
    }
    //读取words
    public Code(boolean w){
        this(FileUtil.readJson(Constant.PATH_WORDS_FILE));
    }
    public Code(String words){
        HashMap<String,Integer> word = new HashMap<>();
        List<Character> characters= new ArrayList<>();
        if (words==null){
            this.character = null;
            return;
        }
        for(int i = 0; i< Objects.requireNonNull(words).length(); i++){
            String w = words.substring(i, i+1);
            if(word.get(w)!=null){
                Integer count = word.get(w);
                word.replace(w,count+1);
            }else {
                word.put(w,1);
            }
        }
        word.forEach((key,value)->{
            characters.add(new Character(key,value));
        });
        creatDictionary(characters);
    }
    public Character creatRoot(List<Character> characters){
        PriorityQueue priorityQueue = new PriorityQueue();
        for (Character character : characters) {
            priorityQueue.enQueue(character );
        }

        while (priorityQueue.getMaxHeap().getData().size()>1){
            Character l = priorityQueue.deQueue();
            Character r = priorityQueue.deQueue();
            Character p = new Character(Constant.SIGN_PARENT,l.getValue()+r.getValue());
            p.getChildren().add(l);
            p.getChildren().add(r);
            priorityQueue.enQueue(p);
        }
        return priorityQueue.deQueue();
    }

    public void creatDictionary(List<Character> characters){
        Character character = creatRoot(characters);
        creatDictionary(character);
    }
    public void creatDictionary(Character character){
        this.character = character;
        HashMap<String,String> ans = new HashMap<>();
        Character.getLeave(ans,character,"");
        this.dictionary=ans;
    }
    public String encoding(String code){
        StringBuilder encode = new StringBuilder();
        for(int i=0;i<code.length();i++){
            String subStr = code.substring(i, i+1);
            encode.append(dictionary.get(subStr));
        }
        return encode.toString();
    }
    public String decoding(String code){
        StringBuilder decode = new StringBuilder();
        int[]num = new int[code.length()];
        for(int i=0;i<code.length();i++){
            String subStr = code.substring(i, i+1);
            num[i] = Integer.parseInt(subStr);
        }
        Character temp = character;
        for(int i = 0;i<num.length;i++){
            if(temp.getName().equals(Constant.SIGN_PARENT)){
                temp = temp.getChildren().get(num[i]);
                if(i == num.length-1){
                    if(!temp.getName().equals(Constant.SIGN_PARENT)){
                        decode.append(temp.getName());
                    }else {
                        decode = null;
                    }
                }
            }else {
                decode.append(temp.getName());
                temp = character;
                i--;
            }
        }
        if (decode==null){
            return "code error";
        }
        return decode.toString();
    }
}